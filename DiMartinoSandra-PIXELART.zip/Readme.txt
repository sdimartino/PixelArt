 "# Pixel Art"

Nota al reviewer 

Con cada uno de los proyectos que entrego, luego de armar la carpeta con el .zip, llevo dicha carpeta a otro directorio, 
la descomprimo y pruebo el proyecto para ver que todo funcione correctamente, previa entrega. 
Para este proyecto agregue algunas funcionalidades extras, entre ellas la carga din�mica de las im�genes al momento
de hacer click en cada una de ellas. Desde mi herramienta de desarrollo (Visual Studio Code) la aplicaci�n funciona sin
errores. Cosa que no sucede si la ejecuto desde el directorio donde descomprimo el .zip del proyecto.
En este caso con DiMartinoSandra-PixelArt.zip, luego de descomprimirlo e intentar cargar las im�genes:
"jquery-3.1.1.js:9536 Access to XMLHttpRequest at 'file:///C:/Users/Home/Desktop/DiMartinoSandra-PIXELART/js/batman.js' from origin 'null' 
has been blocked by CORS policy: Cross origin requests are only supported for protocol schemes: http, data, chrome, chrome-extension, https."
Estuve googleando el error, y por lo que entiendo es que la aplicaci�n se esta corriendo fuera de un httpserver.
Quise detallar estas l�neas para que la persona que lo revise este al tanto del mismo.
